function showMessage(){
  alert('Murakoze kuduhitamo!');
}
